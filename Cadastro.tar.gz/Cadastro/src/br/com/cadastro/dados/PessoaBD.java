package br.com.cadastro.dados;

import br.com.cadastro.entidade.Pessoa;

public class PessoaBD {
	
	public boolean insert (Pessoa pessoa) {
		return true;
	}

}
